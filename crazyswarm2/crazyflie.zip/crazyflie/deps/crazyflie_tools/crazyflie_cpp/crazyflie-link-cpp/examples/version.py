#!/usr/bin/env python3
import cflinkcpp

if __name__ == "__main__":

  print(cflinkcpp.__version__)
